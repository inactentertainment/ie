(()=>{
 const home=document.body.dataset.home==='true'||document.body.classList.contains('home-page');
 if(!home&&document.body.dataset.reader==='true'){
  const bar=document.createElement('aside');bar.id='page-tools';bar.setAttribute('aria-label','i.e. Reading Bar');
  bar.innerHTML='<button class="light-toggle" type="button"></button><div class="reader-utilities"></div><div class="reader-right"></div>';
  document.body.append(bar);
  const footer=document.querySelector('footer');let queued=false;
  function place(){queued=false;const top=footer?footer.getBoundingClientRect().top:innerHeight;bar.style.setProperty('--tools-footer-offset',Math.max(0,innerHeight-top)+'px');bar.hidden=top<=0;document.documentElement.style.setProperty('--reader-bottom',Math.max(0,innerHeight-top)+(bar.hidden?0:bar.getBoundingClientRect().height)+8+'px')}
  window.addEventListener('scroll',()=>{if(!queued){queued=true;requestAnimationFrame(place)}},{passive:true});window.addEventListener('resize',place);place();
  if(typeof ResizeObserver!=='undefined'){const observer=new ResizeObserver(place);[footer,document.querySelector('main'),bar].filter(Boolean).forEach(n=>observer.observe(n))}
 }

})();
